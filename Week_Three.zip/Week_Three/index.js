import React from "react";
import ReactDOM from "react-dom";
import App from "./src/App";
import "tailwindcss/tailwind.css";

ReactDOM.render(<App />, document.getElementById("root"));