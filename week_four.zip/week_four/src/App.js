import React from 'react';

function App() {
  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white text-3xl font-bold">
      Tailwind CSS is working! 🚀
    </div>
  );
}

export default App;
